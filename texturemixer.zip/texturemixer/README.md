# Texture Mixer (Fabric, Minecraft 1.21.11)

Client-Mod: erkennt Texturepacks im `resourcepacks`-Ordner und lässt dich pro Kategorie
(End Crystal, Obsidian, Rüstungen, Schwerter, Totem, Feuer, ...) wählen, aus welchem Pack die Textur kommt.

## Bauen
1. Ordner in IntelliJ IDEA öffnen (JDK 21 einstellen), Gradle importieren lassen.
2. Zum Testen: Gradle-Task `Tasks > fabric > runClient`.
3. Fertige Mod: Task `build`, die Datei liegt in `build/libs/texturemixer-1.0.0.jar`.
   Zusammen mit Fabric API und Mod Menu in den `mods`-Ordner legen.

## Benutzen
- Menü öffnen: Mod Menu > "Texture Mixer" > Konfigurieren-Symbol.
- Pro Kategorie klicken, um durch die Packs zu wechseln ("Standard" = nichts überschreiben).
- Unten: Taste zum Öffnen festlegen (standardmäßig nicht belegt). ESC = Abbruch, Entf = Taste löschen.
- "Anwenden" erzeugt `resourcepacks/texturemixer_output`, aktiviert es ganz oben und lädt die Ressourcen neu.
- Auswahl und Taste werden in `config/texturemixer.json` gespeichert.

## Neue Kategorie hinzufügen
In `Category.java` in `build()` eine Zeile ergänzen, z. B.
`l.add(simple("gapple", "Goldener Apfel", "item/golden_apple.png", "item/enchanted_golden_apple.png"));`

## Hinweise
- Es werden nur Texturen kopiert (assets/minecraft/textures). Packs mit eigenen 3D-Modellen
  für Items brauchen zusätzlich deren Modelle, das ist hier nicht enthalten.
- Alte Rüstungstexturen (`models/armor/*_layer_1/2.png`) werden automatisch ins neue Format umgeleitet.
- Falls Gradle eine Version nicht findet: aktuelle Werte auf https://fabricmc.net/develop eintragen
  (`gradle.properties`).
