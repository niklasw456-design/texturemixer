package de.texturemixer;

import java.util.ArrayList;
import java.util.List;

/**
 * Eine auswählbare Kategorie im Menü.
 * Jede Regel kopiert alle Dateien, deren Pfad (relativ zu assets/minecraft/textures/)
 * mit "src" beginnt, nach "dst" + Rest des Pfads. Dadurch greift ein Prefix wie
 * "block/obsidian.png" automatisch auch für die zugehörige .mcmeta-Datei.
 * Regeln weiter hinten in der Liste überschreiben frühere (neues Format gewinnt vor altem).
 */
public record Category(String id, String name, List<Rule> rules) {

    public record Rule(String src, String dst) {}

    public static final List<Category> ALL = build();

    public boolean matches(String rel) {
        for (Rule r : rules) {
            if (rel.startsWith(r.src())) return true;
        }
        return false;
    }

    private static Rule same(String path) {
        return new Rule(path, path);
    }

    private static Category simple(String id, String name, String... paths) {
        List<Rule> r = new ArrayList<>();
        for (String p : paths) r.add(same(p));
        return new Category(id, name, List.copyOf(r));
    }

    private static Category armor(String id, String name, String itemPrefix, String equip) {
        List<Rule> r = new ArrayList<>();
        // Altes Format (vor 1.21.2) wird automatisch ins neue Format umgeleitet
        r.add(new Rule("models/armor/" + equip + "_layer_1", "entity/equipment/humanoid/" + equip));
        r.add(new Rule("models/armor/" + equip + "_layer_2", "entity/equipment/humanoid_leggings/" + equip));
        // Neues Format
        r.add(same("entity/equipment/humanoid/" + equip));
        r.add(same("entity/equipment/humanoid_leggings/" + equip));
        // Item-Icons
        for (String part : new String[]{"helmet", "chestplate", "leggings", "boots"}) {
            r.add(same("item/" + itemPrefix + "_" + part));
        }
        return new Category(id, name, List.copyOf(r));
    }

    private static List<Category> build() {
        List<Category> l = new ArrayList<>();

        l.add(simple("end_crystal", "End Crystal",
                "entity/end_crystal/", "item/end_crystal.png"));
        l.add(simple("obsidian", "Obsidian", "block/obsidian.png"));
        l.add(simple("crying_obsidian", "Crying Obsidian", "block/crying_obsidian.png"));

        l.add(armor("armor_netherite", "Netherite-Rüstung", "netherite", "netherite"));
        l.add(armor("armor_diamond", "Diamant-Rüstung", "diamond", "diamond"));
        l.add(armor("armor_iron", "Eisen-Rüstung", "iron", "iron"));
        l.add(armor("armor_gold", "Gold-Rüstung", "golden", "gold"));
        l.add(armor("armor_chainmail", "Kettenrüstung", "chainmail", "chainmail"));
        l.add(armor("armor_leather", "Lederrüstung", "leather", "leather"));
        l.add(armor("armor_copper", "Kupfer-Rüstung", "copper", "copper"));
        l.add(new Category("armor_turtle", "Schildkrötenpanzer", List.of(
                new Rule("models/armor/turtle_layer_1", "entity/equipment/humanoid/turtle_scute"),
                same("entity/equipment/humanoid/turtle_scute"),
                same("item/turtle_helmet"))));

        l.add(simple("swords", "Schwerter",
                "item/wooden_sword.png", "item/stone_sword.png", "item/iron_sword.png",
                "item/golden_sword.png", "item/diamond_sword.png", "item/netherite_sword.png",
                "item/copper_sword.png"));
        l.add(simple("totem", "Totem der Unsterblichkeit", "item/totem_of_undying.png"));
        l.add(simple("fire", "Feuer", "block/fire_0.png", "block/fire_1.png"));

        return List.copyOf(l);
    }
}
