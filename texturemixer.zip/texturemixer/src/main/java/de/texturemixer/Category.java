package de.texturemixer;

import java.util.ArrayList;
import java.util.List;

/**
 * Ein Reiter im Menü. Hat er zwei Varianten (Platziert / In der Hand), erscheint oben der Umschalter.
 *
 * Rule:    kopiert alle Dateien, deren Pfad (relativ zu assets/minecraft/textures/) mit "src" beginnt,
 *          nach "dst" + Rest des Pfads. Ein Prefix wie "item/mace.png" greift automatisch auch für die .mcmeta.
 *          Regeln weiter hinten überschreiben frühere (neues Format gewinnt vor altem).
 * HandSpec: für Blöcke/Netze: In der Hand wird ein eigenes Item-Modell erzeugt, das die gewählte Textur nutzt,
 *          unabhängig von der Textur des platzierten Blocks.
 */
public record Category(String id, String name, String icon, List<Variant> variants) {

    public record Rule(String src, String dst) {}

    public record HandSpec(String itemId, boolean cube, List<String> sources) {}

    public record Variant(String key, String label, List<Rule> rules, List<String> previews, HandSpec hand) {
        public boolean matches(String rel) {
            for (Rule r : rules) {
                if (rel.startsWith(r.src())) return true;
            }
            return false;
        }
    }

    public static final List<Category> ALL = build();

    public boolean dual() {
        return variants.size() > 1;
    }

    /** Eindeutiger Schlüssel für Auswahl und Config. */
    public String fullId(Variant v) {
        return dual() ? id + "#" + v.key() : id;
    }

    // ---------- Aufbau ----------

    private static Rule same(String path) {
        return new Rule(path, path);
    }

    private static Variant plain(List<Rule> rules, String... previews) {
        return new Variant("main", "", List.copyOf(rules), List.of(previews), null);
    }

    private static Category single(String id, String name, String icon, Variant v) {
        return new Category(id, name, icon, List.of(v));
    }

    private static Category tool(String id, String name, String item) {
        return single(id, name, item, plain(List.of(same("item/" + item + ".png")), "item/" + item + ".png"));
    }

    private static Category armor(String id, String name, String itemPrefix, String equip) {
        List<Rule> r = new ArrayList<>();
        // Altes Format (vor 1.21.2) wird automatisch ins neue Format umgeleitet
        r.add(new Rule("models/armor/" + equip + "_layer_1", "entity/equipment/humanoid/" + equip));
        r.add(new Rule("models/armor/" + equip + "_layer_2", "entity/equipment/humanoid_leggings/" + equip));
        r.add(same("entity/equipment/humanoid/" + equip));
        r.add(same("entity/equipment/humanoid_leggings/" + equip));
        for (String part : new String[]{"helmet", "chestplate", "leggings", "boots"}) {
            r.add(same("item/" + itemPrefix + "_" + part));
        }
        return single(id, name, itemPrefix + "_chestplate",
                plain(r, "item/" + itemPrefix + "_chestplate.png"));
    }

    /** Block bzw. Netz: platziert = Blocktextur, in der Hand = eigenes Item-Modell mit frei wählbarer Textur. */
    private static Category blockLike(String id, String name, String item, boolean cube) {
        String block = "block/" + item + ".png";
        Variant placed = new Variant("placed", "Platziert", List.of(same(block)), List.of(block), null);
        List<String> sources = List.of("item/" + item + ".png", block);
        Variant hand = new Variant("hand", "In der Hand", List.of(), sources, new HandSpec(item, cube, sources));
        return new Category(id, name, item, List.of(placed, hand));
    }

    private static List<Category> build() {
        List<Category> l = new ArrayList<>();

        l.add(tool("netherite_sword", "Netherite-Schwert", "netherite_sword"));
        l.add(tool("netherite_axe", "Netherite-Axt", "netherite_axe"));
        l.add(tool("netherite_pickaxe", "Netherite-Spitzhacke", "netherite_pickaxe"));
        l.add(armor("netherite_armor", "Netherite-Rüstung", "netherite", "netherite"));

        l.add(tool("diamond_sword", "Diamant-Schwert", "diamond_sword"));
        l.add(tool("diamond_axe", "Diamant-Axt", "diamond_axe"));
        l.add(tool("diamond_pickaxe", "Diamant-Spitzhacke", "diamond_pickaxe"));
        l.add(armor("diamond_armor", "Diamant-Rüstung", "diamond", "diamond"));

        l.add(blockLike("obsidian", "Obsidian", "obsidian", true));
        l.add(blockLike("crying_obsidian", "Crying Obsidian", "crying_obsidian", true));

        // End Crystal: platziert = Entity-Textur, in der Hand = Item-Icon
        Variant crystalPlaced = new Variant("placed", "Platziert",
                List.of(same("entity/end_crystal/")), List.of("entity/end_crystal/end_crystal.png"), null);
        Variant crystalHand = new Variant("hand", "In der Hand",
                List.of(same("item/end_crystal.png")), List.of("item/end_crystal.png"), null);
        l.add(new Category("end_crystal", "End Crystal", "end_crystal", List.of(crystalPlaced, crystalHand)));

        l.add(single("shield", "Schild", "shield", plain(
                List.of(same("entity/shield"), same("item/shield")),
                "entity/shield_base_nopattern.png", "entity/shield/shield_base_nopattern.png",
                "entity/shield_base.png", "entity/shield/shield_base.png")));

        l.add(blockLike("cobweb", "Spinnennetz", "cobweb", false));

        l.add(tool("mace", "Streitkolben", "mace"));

        l.add(single("trident", "Dreizack", "trident", plain(
                List.of(same("item/trident"), same("entity/trident")), "item/trident.png")));

        l.add(single("elytra", "Elytra", "elytra", plain(List.of(
                new Rule("entity/elytra", "entity/equipment/wings/elytra"),
                same("entity/equipment/wings/elytra"),
                same("item/elytra.png"), same("item/broken_elytra.png")), "item/elytra.png")));

        l.add(tool("totem", "Totem", "totem_of_undying"));
        l.add(tool("ender_pearl", "Enderperle", "ender_pearl"));

        l.add(single("golden_apple", "Goldener Apfel", "golden_apple", plain(
                List.of(same("item/golden_apple.png"), same("item/enchanted_golden_apple.png")),
                "item/golden_apple.png")));

        l.add(single("wind_charge", "Windkugel", "wind_charge", plain(
                List.of(same("item/wind_charge.png"), same("entity/projectiles/wind_charge")),
                "item/wind_charge.png")));

        return List.copyOf(l);
    }
}
