package de.texturemixer.gui;

import de.texturemixer.Category;
import de.texturemixer.MixerConfig;
import de.texturemixer.PackApplier;
import de.texturemixer.PackScanner;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MixerScreen extends Screen {
    private static final Map<Integer, String> KEY_NAMES = buildKeyNames();

    private final Screen parent;
    private List<PackScanner.PackInfo> packs;
    private int page = 0;
    private int pages = 1;
    private boolean listening = false;
    private boolean dirty = false;
    private ButtonWidget keyButton;

    public MixerScreen(Screen parent) {
        super(Text.literal("Texture Mixer"));
        this.parent = parent;
        this.packs = PackScanner.scan();
    }

    @Override
    protected void init() {
        int w = 300;
        int x = this.width / 2 - w / 2;

        int rowsPerPage = Math.max(3, (this.height - 112) / 24);
        pages = Math.max(1, (Category.ALL.size() + rowsPerPage - 1) / rowsPerPage);
        page = Math.min(page, pages - 1);

        int start = page * rowsPerPage;
        int end = Math.min(Category.ALL.size(), start + rowsPerPage);
        int y = 32;
        for (int i = start; i < end; i++) {
            Category c = Category.ALL.get(i);
            this.addDrawableChild(ButtonWidget.builder(label(c), b -> {
                cycle(c);
                b.setMessage(label(c));
            }).dimensions(x, y, w, 20).build());
            y += 24;
        }

        int navY = this.height - 78;
        ButtonWidget prev = this.addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            page--;
            this.clearAndInit();
        }).dimensions(x, navY, 40, 20).build());
        prev.active = page > 0;

        ButtonWidget next = this.addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            page++;
            this.clearAndInit();
        }).dimensions(x + w - 40, navY, 40, 20).build());
        next.active = page < pages - 1;

        keyButton = this.addDrawableChild(ButtonWidget.builder(keyLabel(), b -> {
            listening = true;
            b.setMessage(keyLabel());
        }).dimensions(x, this.height - 54, w, 20).build());

        int by = this.height - 28;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Anwenden"), b -> {
            PackApplier.apply();
            dirty = false;
        }).dimensions(x, by, 96, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Neu scannen"), b -> {
            packs = PackScanner.scan();
            this.clearAndInit();
        }).dimensions(x + 102, by, 96, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Fertig"), b -> this.close())
                .dimensions(x + 204, by, 96, 20).build());
    }

    private List<String> options(Category c) {
        List<String> opts = new ArrayList<>();
        opts.add(null); // null = nichts überschreiben
        for (PackScanner.PackInfo p : packs) {
            if (p.categories().contains(c.id())) opts.add(p.name());
        }
        return opts;
    }

    private void cycle(Category c) {
        MixerConfig cfg = MixerConfig.get();
        List<String> opts = options(c);
        String cur = cfg.selections.get(c.id());
        int idx = opts.indexOf(cur); // -1, falls das Pack nicht mehr existiert
        idx = (idx + 1) % opts.size();
        String next = opts.get(idx);
        if (next == null) cfg.selections.remove(c.id());
        else cfg.selections.put(c.id(), next);
        cfg.save();
        dirty = true;
    }

    private Text label(Category c) {
        String sel = MixerConfig.get().selections.get(c.id());
        String shown;
        if (sel == null) {
            shown = "Standard";
        } else {
            boolean exists = packs.stream().anyMatch(p -> p.name().equals(sel) && p.categories().contains(c.id()));
            shown = stripZip(sel) + (exists ? "" : " (fehlt)");
        }
        return Text.literal(c.name() + ": " + shown);
    }

    private static String stripZip(String name) {
        return name.toLowerCase().endsWith(".zip") ? name.substring(0, name.length() - 4) : name;
    }

    private Text keyLabel() {
        if (listening) {
            return Text.literal("> Taste drücken (ESC = Abbruch, Entf = Löschen) <");
        }
        return Text.literal("Taste zum Öffnen: " + keyName(MixerConfig.get().openKey));
    }

    private static String keyName(int key) {
        if (key < 0) return "Nicht belegt";
        String n = KEY_NAMES.get(key);
        return n != null ? n : "Taste " + key;
    }

    private static Map<Integer, String> buildKeyNames() {
        Map<Integer, String> map = new HashMap<>();
        for (Field f : GLFW.class.getFields()) {
            String n = f.getName();
            if (!n.startsWith("GLFW_KEY_") || f.getType() != int.class) continue;
            String shortName = n.substring("GLFW_KEY_".length());
            if (shortName.equals("LAST") || shortName.equals("UNKNOWN")) continue;
            try {
                map.putIfAbsent(f.getInt(null), shortName);
            } catch (IllegalAccessException ignored) {
            }
        }
        return map;
    }

    /** Während der Tastenwahl ESC nicht das Menü schließen lassen. */
    @Override
    public boolean shouldCloseOnEsc() {
        return !listening;
    }

    @Override
    public void tick() {
        super.tick();
        if (!listening || this.client == null) return;

        long handle = this.client.getWindow().getHandle();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (GLFW.glfwGetKey(handle, k) != GLFW.GLFW_PRESS) continue;
            if (k == GLFW.GLFW_KEY_ESCAPE) {
                // Abbruch, Belegung bleibt wie sie war
            } else if (k == GLFW.GLFW_KEY_DELETE || k == GLFW.GLFW_KEY_BACKSPACE) {
                MixerConfig.get().openKey = -1;
                MixerConfig.get().save();
            } else {
                MixerConfig.get().openKey = k;
                MixerConfig.get().save();
            }
            listening = false;
            keyButton.setMessage(keyLabel());
            return;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 7, 0xFFFFFFFF);

        Text status = dirty
                ? Text.literal("Änderungen noch nicht angewendet")
                : Text.literal(packs.size() + " Pack(s) gefunden");
        context.drawCenteredTextWithShadow(this.textRenderer, status, this.width / 2, 18, dirty ? 0xFFFFFF55 : 0xFFAAAAAA);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Seite " + (page + 1) + " / " + pages),
                this.width / 2, this.height - 72, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }
}
