package de.texturemixer.gui;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import de.texturemixer.Category;
import de.texturemixer.PackScanner;
import de.texturemixer.TextureMixerClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Lädt Vorschaubilder aus Packs als GUI-Texturen und merkt sie sich. Unterstützt .mcmeta-Animationen. */
public final class PreviewCache {
    /** Kantenlänge des Vorschaubereichs in GUI-Pixeln. */
    public static final int SIZE = 44;

    private static final Map<String, Preview> CACHE = new HashMap<>();
    private static int counter = 0;

    /** id == null bedeutet: in diesem Pack gibt es kein Vorschaubild. */
    public record Preview(Identifier id, int texW, int texH, int frameW, int frameH,
                          int dw, int dh, int[] frameIdx, int[] frameTicks, int total) {
        public int currentFrame() {
            if (frameIdx.length == 0) return 0;
            long t = (System.currentTimeMillis() / 50L) % Math.max(1, total);
            int acc = 0;
            for (int i = 0; i < frameIdx.length; i++) {
                acc += frameTicks[i];
                if (t < acc) return frameIdx[i];
            }
            return frameIdx[0];
        }
    }

    private static final Preview NONE = new Preview(null, 0, 0, 0, 0, 0, 0, new int[0], new int[0], 1);

    private PreviewCache() {}

    private static String key(PackScanner.PackInfo pack, Category c, Category.Variant v) {
        return pack.name() + "|" + pack.path().toFile().lastModified() + "|" + c.fullId(v);
    }

    /** Gibt das Bild zurück, falls es schon geladen wurde, sonst null. */
    public static Preview peek(PackScanner.PackInfo pack, Category c, Category.Variant v) {
        return CACHE.get(key(pack, c, v));
    }

    /** Lädt das Bild sofort (muss im Render-Thread aufgerufen werden). */
    public static Preview load(PackScanner.PackInfo pack, Category c, Category.Variant v) {
        String k = key(pack, c, v);
        Preview existing = CACHE.get(k);
        if (existing != null) return existing;

        Preview result = NONE;
        try {
            PackScanner.PreviewData data = PackScanner.readPreview(pack, v);
            if (data != null) result = create(data);
        } catch (Exception e) {
            TextureMixerClient.LOGGER.warn("Vorschau für {} / {} konnte nicht geladen werden", pack.name(), c.fullId(v), e);
        }
        CACHE.put(k, result);
        return result;
    }

    private static Preview create(PackScanner.PreviewData data) throws Exception {
        NativeImage src = NativeImage.read(new ByteArrayInputStream(data.png()));
        int w = src.getWidth();
        int h = src.getHeight();

        int fw = w;
        int fh = h;
        int frametime = 1;
        boolean animated = false;
        List<int[]> frames = new ArrayList<>();

        if (data.mcmeta() != null) {
            try {
                JsonObject root = JsonParser.parseString(new String(data.mcmeta(), StandardCharsets.UTF_8)).getAsJsonObject();
                if (root.has("animation") && root.get("animation").isJsonObject()) {
                    JsonObject a = root.getAsJsonObject("animation");
                    animated = true;
                    fw = a.has("width") ? a.get("width").getAsInt() : w;
                    fh = a.has("height") ? a.get("height").getAsInt() : fw;
                    if (fw <= 0 || fh <= 0 || fw > w || fh > h) {
                        fw = w;
                        fh = Math.min(h, w);
                    }
                    if (a.has("frametime")) frametime = Math.max(1, a.get("frametime").getAsInt());
                    if (a.has("frames") && a.get("frames").isJsonArray()) {
                        for (JsonElement e : a.getAsJsonArray("frames")) {
                            int idx;
                            int time = frametime;
                            if (e.isJsonPrimitive()) {
                                idx = e.getAsInt();
                            } else if (e.isJsonObject()) {
                                JsonObject o = e.getAsJsonObject();
                                idx = o.has("index") ? o.get("index").getAsInt() : 0;
                                if (o.has("time")) time = Math.max(1, o.get("time").getAsInt());
                            } else {
                                continue;
                            }
                            frames.add(new int[]{idx, time});
                        }
                    }
                }
            } catch (Exception ignored) {
                animated = false;
            }
        }

        if (!animated) {
            fw = w;
            fh = h;
            frames.clear();
        }

        int count = Math.max(1, h / fh);
        frames.removeIf(f -> f[0] < 0 || f[0] >= count);
        if (frames.isEmpty()) {
            if (animated) {
                for (int i = 0; i < count; i++) frames.add(new int[]{i, frametime});
            } else {
                frames.add(new int[]{0, 1});
            }
        }

        // Pixel-Grafiken ganzzahlig vergrößern, damit sie scharf und nicht verwaschen aussehen
        int s = (int) Math.ceil((double) SIZE / Math.max(fw, fh));
        s = Math.max(1, Math.min(8, s));
        int nw = w * s;
        int nh = h * s;
        NativeImage dst = new NativeImage(NativeImage.Format.RGBA, nw, nh, false);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int argb = src.getColorArgb(x, y);
                for (int dy = 0; dy < s; dy++) {
                    for (int dx = 0; dx < s; dx++) {
                        dst.setColorArgb(x * s + dx, y * s + dy, argb);
                    }
                }
            }
        }
        src.close();

        NativeImageBackedTexture texture = new NativeImageBackedTexture(() -> "texturemixer_preview", dst);
        Identifier id = Identifier.of(TextureMixerClient.MOD_ID, "preview/" + (counter++));
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);

        int sfw = fw * s;
        int sfh = fh * s;
        float f = Math.min((float) SIZE / sfw, (float) SIZE / sfh);
        int dw = Math.max(1, Math.round(sfw * f));
        int dh = Math.max(1, Math.round(sfh * f));

        int[] idx = new int[frames.size()];
        int[] ticks = new int[frames.size()];
        int total = 0;
        for (int i = 0; i < frames.size(); i++) {
            idx[i] = frames.get(i)[0];
            ticks[i] = frames.get(i)[1];
            total += ticks[i];
        }
        return new Preview(id, nw, nh, sfw, sfh, dw, dh, idx, ticks, Math.max(1, total));
    }
}
