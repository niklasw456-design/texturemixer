package de.texturemixer;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/** Findet Texturepacks im resourcepacks-Ordner und baut daraus das Ausgabe-Pack. */
public final class PackScanner {
    public static final String OUTPUT_NAME = "texturemixer_output";

    private static final String MCMETA = """
            {
              "pack": {
                "description": "Texture Mixer (automatisch erzeugt)",
                "pack_format": 75,
                "supported_formats": { "min_inclusive": 34, "max_inclusive": 75 }
              }
            }
            """;

    public record PackInfo(String name, Path path, Set<String> categories) {}

    private interface RootAction<T> {
        T run(Path root) throws IOException;
    }

    private PackScanner() {}

    public static Path packsDir() {
        return FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
    }

    public static List<PackInfo> scan() {
        List<PackInfo> result = new ArrayList<>();
        Path dir = packsDir();
        if (!Files.isDirectory(dir)) return result;

        List<Path> entries;
        try (Stream<Path> s = Files.list(dir)) {
            entries = s.sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase())).toList();
        } catch (IOException e) {
            TextureMixerClient.LOGGER.warn("resourcepacks-Ordner nicht lesbar", e);
            return result;
        }

        for (Path p : entries) {
            String name = p.getFileName().toString();
            if (name.equals(OUTPUT_NAME)) continue;
            boolean zip = Files.isRegularFile(p) && name.toLowerCase().endsWith(".zip");
            boolean folder = Files.isDirectory(p);
            if (!zip && !folder) continue;
            try {
                Set<String> cats = withRoot(p, PackScanner::detect);
                result.add(new PackInfo(name, p, cats));
            } catch (Exception e) {
                TextureMixerClient.LOGGER.warn("Pack {} konnte nicht gelesen werden", name, e);
            }
        }
        return result;
    }

    /** Baut das Ausgabe-Pack. Gibt die Anzahl kopierter Dateien zurück (0 = Pack wurde entfernt). */
    public static int buildOutput(Map<String, String> selections, List<PackInfo> packs) throws IOException {
        Path out = packsDir().resolve(OUTPUT_NAME);
        deleteOutput(out);

        Map<String, List<Category>> byPack = new LinkedHashMap<>();
        for (Category c : Category.ALL) {
            String sel = selections.get(c.id());
            if (sel == null) continue;
            byPack.computeIfAbsent(sel, k -> new ArrayList<>()).add(c);
        }
        if (byPack.isEmpty()) return 0;

        Path outTex = out.resolve("assets").resolve("minecraft").resolve("textures");
        Files.createDirectories(outTex);
        int[] count = {0};

        for (Map.Entry<String, List<Category>> e : byPack.entrySet()) {
            PackInfo info = packs.stream().filter(p -> p.name().equals(e.getKey())).findFirst().orElse(null);
            if (info == null) continue;
            withRoot(info.path(), root -> {
                count[0] += copy(root, e.getValue(), outTex);
                return null;
            });
        }

        if (count[0] == 0) {
            deleteOutput(out);
            return 0;
        }
        Files.writeString(out.resolve("pack.mcmeta"), MCMETA);
        return count[0];
    }

    private static Set<String> detect(Path root) throws IOException {
        Set<String> found = new LinkedHashSet<>();
        Path tex = textures(root);
        if (!Files.isDirectory(tex)) return found;
        List<Path> files;
        try (Stream<Path> s = Files.walk(tex)) {
            files = s.filter(Files::isRegularFile).toList();
        }
        for (Path p : files) {
            String rel = rel(tex, p);
            for (Category c : Category.ALL) {
                if (!found.contains(c.id()) && c.matches(rel)) found.add(c.id());
            }
        }
        return found;
    }

    private static int copy(Path root, List<Category> cats, Path outTex) throws IOException {
        Path tex = textures(root);
        if (!Files.isDirectory(tex)) return 0;
        List<Path> files;
        try (Stream<Path> s = Files.walk(tex)) {
            files = s.filter(Files::isRegularFile).toList();
        }
        int n = 0;
        for (Category c : cats) {
            for (Category.Rule r : c.rules()) {
                for (Path p : files) {
                    String rel = rel(tex, p);
                    if (!rel.startsWith(r.src())) continue;
                    Path target = outTex.resolve(r.dst() + rel.substring(r.src().length()));
                    Files.createDirectories(target.getParent());
                    Files.copy(p, target, StandardCopyOption.REPLACE_EXISTING);
                    n++;
                }
            }
        }
        return n;
    }

    private static Path textures(Path root) {
        return root.resolve("assets").resolve("minecraft").resolve("textures");
    }

    private static String rel(Path base, Path p) {
        return base.relativize(p).toString().replace('\\', '/');
    }

    private static <T> T withRoot(Path pack, RootAction<T> action) throws IOException {
        if (Files.isDirectory(pack)) return action.run(pack);
        try (FileSystem fs = FileSystems.newFileSystem(pack)) {
            return action.run(fs.getPath("/"));
        }
    }

    private static void deleteOutput(Path out) throws IOException {
        if (!Files.exists(out) || !out.getFileName().toString().equals(OUTPUT_NAME)) return;
        List<Path> all;
        try (Stream<Path> s = Files.walk(out)) {
            all = s.sorted(Comparator.reverseOrder()).toList();
        }
        for (Path p : all) Files.deleteIfExists(p);
    }
}
